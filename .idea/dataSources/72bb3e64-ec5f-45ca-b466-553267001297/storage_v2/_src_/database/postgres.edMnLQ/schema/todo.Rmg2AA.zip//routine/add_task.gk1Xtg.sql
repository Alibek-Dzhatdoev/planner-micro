create function add_task() returns trigger
    language plpgsql
as
$$
BEGIN

	/* можно было упаковать все условия в один if-else, но тогда он становится не очень читабельным */
    
    /*  категория НЕПУСТАЯ                и       статус задачи ЗАВЕРШЕН */
    if (coalesce(NEW.category_id, 0)>0 and NEW.completed=1     ) then
		update todo.category set completed_count = (coalesce(completed_count, 0)+1) where id = NEW.category_id and user_id=new.user_id;
	end if;
	
	
	/*  категория НЕПУСТАЯ                 и       статус задачи НЕЗАВЕРШЕН */
    if (coalesce(NEW.category_id, 0)>0      and      coalesce(NEW.completed, 0) = 0) then
		update todo.category set uncompleted_count = (coalesce(uncompleted_count, 0)+1) where id = NEW.category_id and user_id=new.user_id;
	end if;
	
	
	  /* общая статистика */
	if coalesce(NEW.completed, 0) = 1 then
		update todo.stat set completed_total = (coalesce(completed_total, 0)+1)  where user_id=new.user_id;
	else
		update todo.stat set uncompleted_total = (coalesce(uncompleted_total, 0)+1)  where user_id=new.user_id;
    end if;

   

	RETURN NEW;

END
$$;

alter function add_task() owner to postgres;

